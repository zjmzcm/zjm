# 第三方包 from 关键字导入
from flask import Flask
from datetime import timedelta

# 第三方包 import 关键字导入
import os

# 自己的包 from 关键字导入
from blueprints.session import bp as session_bp
from blueprints.cookie import bp as cookie_bp
from blueprints.index import bp as index_bp
from blueprints.info import bp as info_bp
from blueprints.res import bp as res_bp

app = Flask(__name__)
app.config['SECRET_KEY'] = os.urandom(24)
app.config['PERMANENT_SESSION_LIFETIME'] = timedelta(days=10)


# 蓝图注册
app.register_blueprint(session_bp)
app.register_blueprint(cookie_bp)
app.register_blueprint(index_bp)
app.register_blueprint(info_bp)
app.register_blueprint(res_bp)


@app.before_request
def before_request():
    print("每次执行之前都会来到 APP 这里")


if __name__ == '__main__':
    app.run()
