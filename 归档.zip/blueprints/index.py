from flask import Blueprint, request

bp = Blueprint("index", __name__)

# 第二章
@bp.route('/index') # 钥匙 path
def hello_world(): # 锁
    return 'Hello World!'


@bp.route('/index', methods=['GET']) # 钥匙 path
def request_info(): # 锁
    print(request.url)
    print(request.path)
    print(request.full_path)
    return 'Hello World! Redirect Successful'


# URL 传递参数
# 语法格式 <converter:variable>
@bp.route('/index/<int:xh>', methods=['GET']) # 钥匙 path
def get_xh(xh): # 锁
    return f'Hello {xh}!'


# URL 传递参数 2
# <converter:variable>
@bp.route('/index/<int:xh>/<string:name>', methods=['GET']) # 钥匙 path
def get_xh_name(xh, name): # 锁
    return f'Hello {xh}，{name}!'


# UUID 如何使用以及长什么样
import uuid
print(uuid.uuid4())
@bp.route('/index/<uuid:uid>', methods=['GET']) # 钥匙 path
def get_uuid(uid): # 锁
    print(type(uid))
    return f'Hello {uid}!'

# URL 传递参数 与 GET 请求的区别 => RESTFUL API
# /student?xh=20240020&name=chc
# /student/class?bj=ai2302
