from flask import Blueprint, session, jsonify

bp = Blueprint("session", __name__)


# from flask import session
@bp.route('/set_session')
def set_session():
    session['name'] = "session4"
    session.permanent = True
    return jsonify({
        "code":200,
        "msg":"设置session成功",
        "data": session
    })
