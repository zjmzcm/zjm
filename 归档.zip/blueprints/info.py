from flask import Blueprint, request

bp = Blueprint("info", __name__)

# 如何通过 args 获得 GET 请求传递的参数
@bp.route("/info", methods=['GET'])
def using_args():
    name = request.args.get("name")
    print(request.args.get("sex"))
    print(request.args.get("xh"))
    print(request.args.get("shengao"))
    return "Hello World"


# 如何通过第三方测试软件（APIFOX），使用 POST 请求获取
# request.json 获得 POST 请求传递的参数
@bp.route("/info", methods=['POST'])
def using_post():
    print(request.json.get("name"))
    print(request.json.get("sex"))
    print(request.json.get("xh"))
    print(request.json.get("shengao"))
    return "Hello World"