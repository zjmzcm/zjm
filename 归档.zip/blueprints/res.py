from flask import Blueprint, redirect, url_for, jsonify

bp = Blueprint("res", __name__)

# URL 反转
# /info => @app.route("/info", methods=['POST'])
# /info => @app.route("/info", methods=['POST']) => 重新定向到另外一个 @app.route("/index", methods=['POST'])

# URL 重定向 重新定向 网页信息 => 另外一个地方 （/redi => /index）
# from flask import redirect, url_for
@bp.route("/redi")
def using_redirect():
    return redirect(url_for("request_info"))


# jsonify
# from flask import jsonify
@bp.route("/res", methods=['POST'])
def using_jsonify():
    data = {
        "name": "chc",
        "sex": "male",
        "xh": 20240020,
        "shengao": 100
    }
    return jsonify({
        "code": 200,
        "data": data,
        "msg": "成功返回 jsonify 信息"
    })
