from flask import Blueprint

bp = Blueprint("", __name__)

