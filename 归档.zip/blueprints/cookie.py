from flask import Blueprint, make_response, jsonify, request

# 声明蓝图的名称
bp = Blueprint("cookie", __name__)

# cookie 身份认证
# from flask import make_response
import datetime
# 蓝图一定是 bp.route 开头，不是 app.route
@bp.route("/set_cookie", methods=['GET'])
def using_set_cookie():
    res = make_response("create a cookie")
    res.set_cookie("cookie4", "flaskCookieTest", max_age=3600)
    res.set_cookie("cookie4-1", "flaskCookieTestMagAge1", max_age=3600)
    # res.headers["Set-Cookie"] = "cookie4-2=flaskCookieHeaders;Max-Age=200"
    return res


# @bp.route('/set_cookie')
# def set_cookie():
#     resp = make_response("create a cookie")
#     # 设置cookie,默认有效期是临时cookie，浏览器关闭就失效
#     resp.set_cookie("name1", "Python1")
#     # #过期时间为北京时间2022-12-31 23:59:59
#     resp.set_cookie("name2", "Python2",expires=datetime(2024,12,31,23,59,59))
#     # #过期时间3600秒
#     resp.set_cookie("name3", "Python3", max_age=3600)
#     # 通过表单头来实现Cookie设置
#     # resp.headers["Set-Cookie"] = "name4=python4;Max-Age=200"
#     return resp


@bp.route('/get_cookie', methods=['GET'])
def get_cookie():
    cookie_name = request.args.get("cookie_name")
    cookie = request.cookies.get(cookie_name)
    return jsonify({
        "code": 200,
        "data": cookie,
        "msg": "成功获取Cookie的值"
    })


@bp.route('/del_cookie/<string:name>')
def del_cookie(name):
    resp = make_response("delete cookie success")
    resp.delete_cookie(name)
    return resp


